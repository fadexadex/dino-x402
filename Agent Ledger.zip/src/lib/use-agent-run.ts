import { useCallback, useEffect, useRef, useState } from "react";
import type { AgentEvent, Tick } from "./agent-types";
import { RUN_CONNECT, RUN_ONE, RUN_ONE_APPROVED, RUN_TWO, type ScriptStep } from "./agent-script";

export type Phase = "idle" | "connecting" | "running" | "awaiting" | "executing" | "settled" | "second";

const PROPOSAL_TTL = 90_000;
const CONNECT_KEY = "dino-agent.connected";


function seedTicks(): Tick[] {
  const out: Tick[] = [];
  const now = Date.now();
  let p = 0.0669;
  for (let i = 96; i >= 0; i--) {
    p += (Math.random() - 0.46) * 0.00042;
    out.push({
      t: now - i * 15_000,
      price: Number(p.toFixed(5)),
      provenance: i > 30 && i < 44 ? "fallback" : i % 8 === 0 ? "live" : "cached",
    });
  }
  return out;
}

export function useAgentRun() {
  const [events, setEvents] = useState<AgentEvent[]>([]);
  const [phase, setPhase] = useState<Phase>("idle");
  const [ticks, setTicks] = useState<Tick[]>(() => seedTicks());
  const [markers, setMarkers] = useState<{ t: number; eventId: string }[]>([]);
  const [expiresAt, setExpiresAt] = useState<number | null>(null);
  const [halted, setHalted] = useState(false);
  const [nonce, setNonce] = useState(0);
  const [connected, setConnected] = useState(false);
  const timers = useRef<ReturnType<typeof setTimeout>[]>([]);


  const clearTimers = useCallback(() => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
  }, []);

  const play = useCallback(
    (script: ScriptStep[], onDone?: () => void) => {
      let acc = 0;
      script.forEach((step) => {
        acc += step.after;
        timers.current.push(
          setTimeout(() => {
            const at = Date.now();
            const ev: AgentEvent = { ...step.event, at };
            if (ev.proposal) {
              const exp = at + PROPOSAL_TTL;
              ev.proposal = { ...ev.proposal, expiresAt: exp };
              setExpiresAt(exp);
            }
            if (ev.settlement) ev.settlement = { ...ev.settlement, submittedAt: at };
            setEvents((prev) => [...prev, ev]);
            if (ev.step === "verify") setMarkers((m) => [...m, { t: at, eventId: ev.id }]);
          }, acc),
        );
      });
      timers.current.push(setTimeout(() => onDone?.(), acc + 200));
    },
    [],
  );

  // price ticks
  useEffect(() => {
    if (halted) return;
    const t = setInterval(() => {
      setTicks((prev) => {
        const last = prev[prev.length - 1]!;
        const next: Tick = {
          t: Date.now(),
          price: Number((last.price + (Math.random() - 0.48) * 0.00035).toFixed(5)),
          provenance: Math.random() > 0.8 ? "live" : "cached",
        };
        return [...prev.slice(-140), next];
      });
    }, 1600);
    return () => clearInterval(t);
  }, [halted]);

  // resume a previous connection (the /connect screen sets this)
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      if (window.localStorage.getItem(CONNECT_KEY) === "1") setConnected(true);
    } catch {
      /* ignore */
    }
  }, []);

  // run script — only once an account is connected
  useEffect(() => {
    if (!connected) return;
    clearTimers();
    setEvents([]);
    setMarkers([]);
    setExpiresAt(null);
    setPhase("connecting");
    play(RUN_CONNECT, () => {
      setPhase("running");
      play(RUN_ONE, () => setPhase("awaiting"));
    });
    return clearTimers;
  }, [nonce, connected, clearTimers, play]);


  const approve = useCallback(() => {
    setPhase("executing");
    setExpiresAt(null);
    play(RUN_ONE_APPROVED, () => {
      setPhase("settled");
      timers.current.push(
        setTimeout(() => {
          setPhase("second");
          play(RUN_TWO, () => setPhase("settled"));
        }, 2600),
      );
    });
  }, [play]);

  const decline = useCallback(() => {
    setExpiresAt(null);
    setPhase("settled");
    setEvents((prev) => [
      ...prev,
      {
        id: "e9-decline",
        step: "record",
        at: Date.now(),
        title: "Declined — proposal discarded",
        detail: "Nothing was submitted on-chain. The agent will re-evaluate at the next check-in.",
        tone: "ink",
      },
    ]);
  }, []);

  const connect = useCallback(() => {
    try {
      window.localStorage.setItem(CONNECT_KEY, "1");
    } catch {
      /* ignore */
    }
    setConnected(true);
    setNonce((n) => n + 1);
  }, []);

  const disconnect = useCallback(() => {
    clearTimers();
    try {
      window.localStorage.removeItem(CONNECT_KEY);
    } catch {
      /* ignore */
    }
    setConnected(false);
    setEvents([]);
    setMarkers([]);
    setExpiresAt(null);
    setPhase("idle");
  }, [clearTimers]);

  const replay = useCallback(() => {
    setHalted(false);
    setNonce((n) => n + 1);
  }, []);


  const halt = useCallback(() => {
    clearTimers();
    setHalted(true);
    setExpiresAt(null);
    setPhase("settled");
    setEvents((prev) => [
      ...prev,
      {
        id: `halt-${Date.now()}`,
        step: "record",
        at: Date.now(),
        title: "Everything halted",
        detail:
          "Scheduler stopped, pending proposals voided, autonomous execution blocked across all portfolios.",
        tone: "orange",
      },
    ]);
  }, [clearTimers]);

  return {
    events,
    phase,
    ticks,
    markers,
    expiresAt,
    halted,
    connected,
    connect,
    disconnect,
    approve,
    decline,

    replay,
    halt,
    resume: () => setHalted(false),
  };
}
