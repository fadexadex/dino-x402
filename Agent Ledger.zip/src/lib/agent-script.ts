import type { AgentEvent, Holding, Limits, Proposal, Purchase } from "./agent-types";

export const ACCOUNT = "0.0.4821907";

export const LIMITS: Limits = {
  maxPerTrade: 250,
  maxTradesPerDay: 6,
  maxPortfolioMovePct: 12,
  maxDailySpend: 4.0,
  allowList: ["HBAR", "USDC", "SAUCE"],
};

export const HOLDINGS: Holding[] = [
  { asset: "HBAR", amount: 18420.55, usd: 1284.31 },
  { asset: "USDC", amount: 612.4, usd: 612.4 },
  { asset: "SAUCE", amount: 9840.0, usd: 231.24 },
];

export const OBJECTIVE =
  "Hold HBAR exposure under 65% of portfolio value; rotate excess into USDC on strength.";

const hash = (seed: string) =>
  `0.0.4821907@17${seed}.${Math.floor(100000000 + Number(seed) * 7919).toString().slice(0, 9)}`;

export type ScriptStep = {
  after: number;
  event: Omit<AgentEvent, "at">;
};

const purchase = (
  id: string,
  label: string,
  endpoint: string,
  costUsd: number,
  seed: string,
  ms: number,
  provenance: Purchase["provenance"] = "live",
): Purchase => ({
  id,
  label,
  endpoint,
  costUsd,
  asset: "USDC",
  txHash: hash(seed),
  provenance,
  ms,
});

export const PROPOSAL: Proposal = {
  id: "prop_01",
  from: "HBAR",
  to: "USDC",
  amount: 2100,
  expectedRate: 0.0697,
  slippagePct: 0.21,
  resultingPosition: "HBAR 61.4% · USDC 33.2% · SAUCE 5.4%",
  expiresAt: 0,
  reason:
    "HBAR is 68.4% of portfolio value, above the 65% ceiling. Momentum is positive but decelerating; rotating 2,100 HBAR restores the band without over-selling.",
  withinLimits: false,
  breach: "Trade value $146.37 is within per-trade cap, but portfolio move 13.1% exceeds the 12% cap",
};

/** The primary scripted run: check-in → paid data → proposal → approval → settlement. */
export const RUN_ONE: ScriptStep[] = [
  {
    after: 300,
    event: {
      id: "e1",
      step: "trigger",
      title: "Scheduled check-in fired",
      detail: "Cadence: every 15 minutes",
      tone: "ink",
    },
  },
  {
    after: 1100,
    event: {
      id: "e2",
      step: "observe",
      title: "Read portfolio from mirror node",
      detail: "Free read · no payment required",
      provenance: "cached",
      rows: [
        { primary: "HBAR", secondary: "18,420.55 · $1,284.31", mono: true },
        { primary: "USDC", secondary: "612.40 · $612.40", mono: true },
        { primary: "SAUCE", secondary: "9,840.00 · $231.24", mono: true },
      ],
    },
  },
  {
    after: 1400,
    event: {
      id: "e3",
      step: "judge",
      title: "New intelligence is worth buying",
      detail:
        "HBAR weight drifted 3.4pt since the last paid read, past the 2pt threshold that justifies spend. Remaining daily budget $3.61.",
      tone: "ink",
    },
  },
  {
    after: 1600,
    event: {
      id: "e4",
      step: "acquire",
      title: "Paid for live HBAR/USDC quote",
      purchase: purchase("p1", "HBAR/USDC spot + depth", "GET /x402/quote/hbar-usdc", 0.001, "231", 412),
      tone: "signal",
    },
  },
  {
    after: 900,
    event: {
      id: "e5",
      step: "acquire",
      title: "Paid for 24h momentum window",
      purchase: purchase("p2", "24h OHLCV, 5m buckets", "GET /x402/ohlcv/hbar?w=24h", 0.001, "247", 508),
      tone: "signal",
    },
  },
  {
    after: 1900,
    event: {
      id: "e6",
      step: "reason",
      title: "Interpreted against the objective",
      detail:
        "Spot 0.0697 with thin sell-side depth above 0.0703. Momentum positive but the 5m slope has flattened for 40 minutes. HBAR weight 68.4% vs the 65% ceiling — a partial rotation restores the band without giving up the trend.",
    },
  },
  {
    after: 1200,
    event: {
      id: "e7",
      step: "propose",
      title: "Constructed a trade",
      proposal: PROPOSAL,
      tone: "orange",
    },
  },
  {
    after: 700,
    event: {
      id: "e8",
      step: "gate",
      title: "Held for approval — limit breach",
      detail: PROPOSAL.breach ?? "",
      tone: "orange",
    },
  },
];

/** Continues once the user approves. */
export const RUN_ONE_APPROVED: ScriptStep[] = [
  {
    after: 200,
    event: {
      id: "e9",
      step: "decide",
      title: "Approved by you",
      detail: "Terms locked at the quoted rate. This is the last reversible moment.",
      tone: "ink",
    },
  },
  {
    after: 400,
    event: {
      id: "e10",
      step: "execute",
      title: "Swap submitted to SaucerSwap",
      settlement: {
        txHash: hash("312"),
        status: "submitted",
        feeUsd: 0.0001,
        submittedAt: 0,
      },
      tone: "signal",
    },
  },
  {
    after: 3200,
    event: {
      id: "e11",
      step: "verify",
      title: "Settled on Hedera",
      detail: "2,100 HBAR → 146.32 USDC · fee $0.0001 · 2 consensus rounds",
      tone: "green",
    },
  },
  {
    after: 600,
    event: {
      id: "e12",
      step: "record",
      title: "Recorded to history",
      detail: "Run 0142 · 2 paid reads ($0.002) · 1 trade · full trace retained",
      tone: "green",
    },
  },
];

/** A second run that concludes nothing is warranted. */
export const RUN_TWO: ScriptStep[] = [
  {
    after: 1200,
    event: {
      id: "f1",
      step: "trigger",
      title: "Scheduled check-in fired",
      detail: "Cadence: every 15 minutes",
    },
  },
  {
    after: 1100,
    event: {
      id: "f2",
      step: "observe",
      title: "Read portfolio from mirror node",
      detail: "Free read · no payment required",
      provenance: "cached",
    },
  },
  {
    after: 1500,
    event: {
      id: "f3",
      step: "judge",
      title: "Not worth buying data",
      detail:
        "HBAR weight moved 0.3pt since the last paid read — under the 2pt threshold. Skipping paid intelligence keeps $3.61 of today's budget intact.",
    },
  },
  {
    after: 900,
    event: {
      id: "f4",
      step: "noop",
      title: "Checked in — nothing warranted",
      detail: "Next check-in in 15 minutes.",
      tone: "green",
    },
  },
];

export const SPEND = {
  dataToday: 0.014,
  dataAllTime: 0.212,
  tradeVolumeToday: 146.32,
  tradeVolumeAllTime: 2841.9,
  networkFeesAllTime: 0.0037,
  paidReadsAllTime: 212,
  tradesAllTime: 18,
};

export const LEDGER_ROWS = [
  { run: "0142", data: 0.002, reads: 2, trade: 146.32, fee: 0.0001, outcome: "Settled" },
  { run: "0141", data: 0.001, reads: 1, trade: 0, fee: 0, outcome: "No action" },
  { run: "0140", data: 0.003, reads: 3, trade: 88.4, fee: 0.0001, outcome: "Settled" },
  { run: "0139", data: 0, reads: 0, trade: 0, fee: 0, outcome: "No action" },
  { run: "0138", data: 0.002, reads: 2, trade: 0, fee: 0, outcome: "Expired" },
];

/** Wallet connection, replayed as part of the demo so the whole flow is visible. */
export const RUN_CONNECT: ScriptStep[] = [
  {
    after: 250,
    event: {
      id: "c1",
      step: "trigger",
      title: "Wallet connect requested",
      detail: "HashPack · Hedera testnet",
      tone: "ink",
    },
  },
  {
    after: 900,
    event: {
      id: "c2",
      step: "observe",
      title: `Account ${ACCOUNT} connected`,
      detail:
        "Session opened read-only. The agent can observe balances immediately; spending and trading stay blocked until you raise the autonomy mode.",
      tone: "green",
      rows: [
        { primary: "Network", secondary: "hedera testnet", mono: true },
        { primary: "Session", secondary: "read-only", mono: true },
      ],
    },
  },
  {
    after: 900,
    event: {
      id: "c3",
      step: "observe",
      title: "Portfolio indexed from mirror node",
      detail: "3 assets · $2,127.95 total · free read, no payment required",
      provenance: "cached",
    },
  },
  {
    after: 800,
    event: {
      id: "c4",
      step: "record",
      title: "Watch armed — cadence every 15 minutes",
      detail: "Demo data. Nothing here touches a real balance.",
      tone: "signal",
    },
  },
];
