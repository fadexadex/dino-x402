import { createContext, useContext, useEffect, useMemo, useState } from "react";

export const VARIANT_REGISTRY = {
  font: {
    label: "Typeface",
    hint: "Sans + mono pairing",
    options: ["Inter Tight", "Geist", "IBM Plex", "Space Grotesk", "Söhne-ish"],
  },
  eventCard: {
    label: "Agent event",
    hint: "How each lifecycle step reads in the stream",
    options: ["Trace line", "Card stack", "Terminal"],
  },

  receipt: {
    label: "Paid-data receipt",
    hint: "The x402 micropayment moment",
    options: ["Inline chip", "Receipt strip", "Cost meter"],
  },
  proposal: {
    label: "Proposal gate",
    hint: "Human-in-the-loop approval",
    options: ["Inline", "Sticky bar", "Takeover"],
  },
  autonomy: {
    label: "Autonomy dial",
    hint: "Modes 1–4 and their hard limits",
    options: ["Vertical dial", "Segmented", "Limits card"],
  },
  rightNow: {
    label: "“Right now” placement",
    hint: "Where the live activity panel sits",
    options: ["Left rail", "Sticky under header", "Inline card", "Above composer"],
  },
  watch: {
    label: "Watch status",
    hint: "Last / next check-in",
    options: ["Header pill", "Rail block"],
  },

  graph: {
    label: "Live graph",
    hint: "Composition against market context",
    options: ["Overlay", "Split stacked", "Sparkline strip"],
  },
  graphPlacement: {
    label: "Graph / inspector placement",
    hint: "Where the analysis panel lives",
    options: ["Split right", "Right drawer", "Split bottom", "Full focus"],
  },

  ledger: {
    label: "Spend ledger",
    hint: "Data spend vs. trade volume",
    options: ["Split bar", "Table"],
  },
  kill: {
    label: "Kill switch",
    hint: "Global halt",
    options: ["Header icon", "Rail footer"],
  },
  loader: {
    label: "In-flight loader",
    hint: "Submitted, not yet confirmed",
    options: ["Drive", "Dots", "Orbit"],
  },
} as const;

export type VariantKey = keyof typeof VARIANT_REGISTRY;
export type VariantState = Record<VariantKey, string>;

const DEFAULTS = Object.fromEntries(
  Object.entries(VARIANT_REGISTRY).map(([k, v]) => [k, v.options[0]]),
) as VariantState;

const STORAGE_KEY = "dino-agent.variants";

type Ctx = {
  variants: VariantState;
  set: (key: VariantKey, value: string) => void;
  reset: () => void;
  density: "comfortable" | "compact";
  setDensity: (d: "comfortable" | "compact") => void;
};

const VariantContext = createContext<Ctx | null>(null);

export function VariantProvider({ children }: { children: React.ReactNode }) {
  const [variants, setVariants] = useState<VariantState>(DEFAULTS);
  const [density, setDensity] = useState<"comfortable" | "compact">("comfortable");

  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setVariants({ ...DEFAULTS, ...JSON.parse(raw) });
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    if (typeof document === "undefined") return;
    const slug: Record<string, string> = {
      "Inter Tight": "inter",
      Geist: "geist",
      "IBM Plex": "plex",
      "Space Grotesk": "grotesk",
      "Söhne-ish": "sohne",
    };
    document.documentElement.setAttribute("data-font", slug[variants["font"]] ?? "inter");
  }, [variants]);




  const value = useMemo<Ctx>(
    () => ({
      variants,
      density,
      setDensity,
      set: (key, val) =>
        setVariants((prev) => {
          const next = { ...prev, [key]: val };
          try {
            window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
          } catch {
            /* ignore */
          }
          return next;
        }),
      reset: () => {
        setVariants(DEFAULTS);
        try {
          window.localStorage.removeItem(STORAGE_KEY);
        } catch {
          /* ignore */
        }
      },
    }),
    [variants, density],
  );

  return <VariantContext.Provider value={value}>{children}</VariantContext.Provider>;
}

export function useVariants() {
  const ctx = useContext(VariantContext);
  if (!ctx) throw new Error("useVariants must be used inside VariantProvider");
  return ctx;
}

export function useVariant(key: VariantKey) {
  return useVariants().variants[key];
}
