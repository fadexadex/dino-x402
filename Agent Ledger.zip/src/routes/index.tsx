import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { DinoMark } from "@/components/agent/DinoMark";
import { EventCard } from "@/components/agent/EventCard";
import { ProposalGate } from "@/components/agent/ProposalGate";
import { AutonomyDial } from "@/components/agent/AutonomyDial";
import { WatchStatus } from "@/components/agent/WatchStatus";
import { KillSwitch } from "@/components/agent/KillSwitch";
import { RunsRail } from "@/components/agent/RunsRail";
import { Composer } from "@/components/agent/Composer";
import { Inspector, type InspectorView } from "@/components/agent/Inspector";
import { ThinkingTrace } from "@/components/kit/ThinkingTrace";
import { useAgentRun } from "@/lib/use-agent-run";
import { ACCOUNT, LIMITS } from "@/lib/agent-script";
import type { AgentEvent, AutonomyMode, Limits } from "@/lib/agent-types";
import { useVariant, useVariants } from "@/lib/variants";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dino Agent — an autonomous portfolio agent that pays per query" },
      {
        name: "description",
        content:
          "Watch an autonomous agent observe your portfolio, pay for market intelligence over x402, and settle every trade on Hedera with a full inspectable trail.",
      },
      { property: "og:title", content: "Dino Agent — autonomous portfolio agent on x402 + Hedera" },
      {
        property: "og:description",
        content:
          "Agent-first interface: live reasoning, per-query micropayments, approval gates, and on-chain proof for every action.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AgentPage,
});

/** Locked-in scroll style for the workspace rail. */
const WORKSPACE_SCROLL = "scroll-snap-cards scroll-fade";

function AgentPage() {

  const run = useAgentRun();
  const [mode, setMode] = useState<AutonomyMode>(4);
  const [limits, setLimits] = useState<Limits>(LIMITS);
  const [paused, setPaused] = useState(false);
  const [cadenceMs, setCadenceMs] = useState(15 * 60 * 1000);
  const [inspector, setInspector] = useState<InspectorView | null>(null);
  const [focusId, setFocusId] = useState<string | null>(null);
  const proposalVariant = useVariant("proposal");
  const rightNowPlacement = useVariant("rightNow");
  const graphPlacement = useVariant("graphPlacement");
  const [railOpen, setRailOpen] = useState(true);

  const { density } = useVariants();
  const streamRef = useRef<HTMLDivElement>(null);
  const stickToBottom = useRef(true);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === "b" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setRailOpen((o) => !o);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);


  const proposalEvent = run.events.find((e) => e.proposal);
  const awaiting = run.phase === "awaiting" && !!proposalEvent?.proposal;
  const lastCheckIn = run.events[0]?.at ?? Date.now();
  const working = run.phase === "running" || run.phase === "executing" || run.phase === "connecting";

  // keep the stream pinned to the newest step unless the user scrolled up
  useEffect(() => {
    const el = streamRef.current;
    if (!el || !stickToBottom.current) return;
    el.scrollTo({ top: el.scrollHeight, behavior: "smooth" });
  }, [run.events.length, run.phase]);

  const onStreamScroll = () => {
    const el = streamRef.current;
    if (!el) return;
    stickToBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 120;
  };

  const openInspector = (view: InspectorView, id?: string) => {
    setInspector(view);
    if (id) setFocusId(id);
  };

  const inspect = (event: AgentEvent) => openInspector("trace", event.id);

  const liveRows = useMemo(
    () =>
      run.events.slice(-4).map((e) => ({
        primary: e.title,
        secondary: e.step,
        tone: e.tone ?? "ink",
      })),
    [run.events],
  );

  const rightNow = (
    <ThinkingTrace
      activeLabel={
        run.phase === "connecting"
          ? "Connecting your wallet"
          : run.phase === "executing"
            ? "Settling on Hedera"
            : "Working the check-in"
      }
      doneLabel={
        awaiting
          ? "Paused for your approval"
          : run.halted
            ? "Halted"
            : run.connected
              ? `Ran ${run.events.length} steps`
              : "No account connected"
      }
      rows={liveRows}
      visible={liveRows.length}
      working={working}
      defaultExpanded={rightNowPlacement !== "Sticky under header"}
      onRowClick={(_r, i) => {
        const ev = run.events.slice(-4)[i];
        if (ev) inspect(ev);
      }}
    />
  );

  const rightNowCard = (
    <div className="rounded-lg border border-line bg-card p-3">
      <p className="text-[10.5px] font-medium tracking-[0.09em] text-ink-3 uppercase">Right now</p>
      <div className="mt-2">{rightNow}</div>
    </div>
  );

  const gap = density === "compact" ? "gap-3" : "gap-5";

  const panel = (tall: boolean) =>
    inspector ? (
      <Inspector
        view={inspector}
        ticks={run.ticks}
        markers={run.markers}
        events={run.events}
        focusId={focusId}
        tall={tall}
        onView={setInspector}
        onFocus={setFocusId}
        onClose={() => setInspector(null)}
      />
    ) : null;


  return (
    <div className="flex h-screen flex-col bg-paper text-ink">
      <header className="flex shrink-0 items-center gap-3 border-b border-line px-4 py-2.5">
        <span className="flex items-center gap-2 text-ink">
          <DinoMark />
          <span className="text-[13.5px] font-semibold tracking-[-0.01em]">Dino Agent</span>
        </span>
        <button
          type="button"
          onClick={run.connected ? run.disconnect : run.connect}
          className="hidden items-center gap-1.5 rounded-full border border-line bg-card px-2.5 py-1 font-mono text-[11px] text-ink-3 transition-colors hover:bg-hover sm:flex"
        >
          <span className={`size-1.5 rounded-full ${run.connected ? "bg-green" : "bg-ink-3"}`} />
          {run.connected ? `${ACCOUNT} · testnet` : "connect wallet"}
        </button>
        <div className="ml-auto flex items-center gap-2">
          <WatchStatus
            lastCheckIn={lastCheckIn}
            cadenceMs={cadenceMs}
            onCadenceChange={setCadenceMs}
            paused={paused || run.halted || !run.connected}
            onTogglePause={() => setPaused((p) => !p)}
          />
          <button
            type="button"
            onClick={() => openInspector(inspector === "graph" ? "trace" : "graph")}
            className="rounded-control border border-line bg-card px-2.5 py-1.5 text-[12px] text-ink-2 transition-colors hover:bg-hover"
          >
            Graph
          </button>
          <KillSwitch halted={run.halted} onHalt={run.halt} />
        </div>
      </header>

      {rightNowPlacement === "Sticky under header" && (
        <div className="shrink-0 border-b border-line bg-card/70 px-5 py-2">
          <div className="mx-auto w-full max-w-3xl">{rightNow}</div>
        </div>
      )}

      <div className="flex min-h-0 flex-1">
        <div
          className={`hidden shrink-0 overflow-hidden border-r border-line transition-[width] duration-300 ease-[cubic-bezier(0.23,1,0.32,1)] lg:block ${
            railOpen ? "w-[260px]" : "w-[52px]"
          }`}
        >
          {railOpen ? (
            <div className="flex h-full w-[260px] min-h-0 flex-col p-3">
              <div className="flex shrink-0 items-center justify-between gap-1 pb-3">
                <span className="min-w-0 truncate text-[10.5px] font-medium tracking-[0.09em] text-ink-3 uppercase">
                  Workspace
                </span>
                <button
                  type="button"
                  onClick={() => setRailOpen(false)}
                  aria-label="Collapse sidebar"
                  title="Collapse sidebar (⌘B)"
                  className="rounded-control px-1.5 py-1 text-[12px] text-ink-3 transition-colors hover:bg-hover hover:text-ink"
                >
                  ⟨⟨
                </button>
              </div>
              <div
                className={`-mr-1 flex min-h-0 flex-1 flex-col gap-3 overflow-y-auto overscroll-contain scroll-smooth pr-1 ${WORKSPACE_SCROLL}`}
              >
                {rightNowPlacement === "Left rail" && rightNowCard}
                <RunsRail pendingCount={awaiting ? 1 : 0} />
              </div>
            </div>

          ) : (
            <div className="flex h-full w-[52px] flex-col items-center gap-3 py-3">
              <button
                type="button"
                onClick={() => setRailOpen(true)}
                aria-label="Expand sidebar"
                title="Expand sidebar (⌘B)"
                className="rounded-control px-1.5 py-1 text-[12px] text-ink-3 transition-colors hover:bg-hover hover:text-ink"
              >
                ⟩⟩
              </button>
              <span
                className={`size-2 rounded-full ${working ? "animate-pulse bg-signal" : awaiting ? "bg-orange" : "bg-ink-3/40"}`}
                title={working ? "Agent working" : awaiting ? "Awaiting approval" : "Idle"}
              />
            </div>
          )}
        </div>

        <div className="flex min-h-0 flex-1 flex-col">
          <div className="flex min-h-0 flex-1">
            <main className="flex min-h-0 flex-1 flex-col">
              <div
                ref={streamRef}
                onScroll={onStreamScroll}
                className={`flex min-h-0 flex-1 flex-col overflow-auto px-5 py-5 ${gap}`}
              >
                <div className="mx-auto flex w-full max-w-3xl flex-col gap-5">
                  <section
                    className={`grid gap-3 ${rightNowPlacement === "Inline card" ? "sm:grid-cols-2" : ""}`}
                  >
                    <AutonomyDial
                      mode={mode}
                      limits={limits}
                      onChange={setMode}
                      onLimitsChange={setLimits}
                    />
                    {rightNowPlacement === "Inline card" && rightNowCard}
                  </section>

                  {!run.connected && (
                    <section className="rounded-lg border border-line bg-card p-5 text-center">
                      <p className="text-[14px] font-medium text-ink">
                        Connect an account to start the demo run
                      </p>
                      <p className="mx-auto mt-1.5 max-w-md text-[12.5px] leading-relaxed text-ink-2">
                        The whole flow is replayed on mock data: wallet connect, the scheduled
                        check-in, paid x402 reads, the approval gate, and Hedera settlement.
                      </p>
                      <div className="mt-3 flex items-center justify-center gap-2">
                        <button
                          type="button"
                          onClick={run.connect}
                          className="rounded-control bg-ink px-3 py-1.5 text-[12.5px] font-medium text-background"
                        >
                          Connect demo wallet
                        </button>
                        <Link
                          to="/connect"
                          className="rounded-control border border-line px-3 py-1.5 text-[12.5px] text-ink-2 hover:bg-hover"
                        >
                          Pick a wallet
                        </Link>
                      </div>
                    </section>
                  )}

                  <section className={`flex flex-col ${density === "compact" ? "gap-3" : "gap-4"}`}>
                    {run.events.map((event) => (
                      <EventCard
                        key={event.id}
                        event={event}
                        onInspect={inspect}
                        onGraph={(e) => openInspector("graph", e.id)}
                      >

                        {event.proposal && awaiting && proposalVariant === "Inline" && (
                          <ProposalGate
                            proposal={event.proposal}
                            onApprove={run.approve}
                            onDecline={run.decline}
                          />
                        )}
                      </EventCard>
                    ))}
                  </section>
                </div>
              </div>

              <div className="shrink-0 border-t border-line bg-paper px-5 py-3">
                <div className="mx-auto w-full max-w-3xl">
                  {rightNowPlacement === "Above composer" && <div className="mb-3">{rightNow}</div>}
                  {awaiting && proposalEvent?.proposal && proposalVariant === "Sticky bar" && (
                    <div className="mb-3">
                      <ProposalGate
                        proposal={proposalEvent.proposal}
                        onApprove={run.approve}
                        onDecline={run.decline}
                      />
                    </div>
                  )}
                  <Composer onSend={() => openInspector("trace")} disabled={run.halted} />
                  <p className="mt-2 text-[11px] text-ink-3">
                    Mode {mode} · every paid read and every trade is on-chain and inspectable ·{" "}
                    <Link to="/connect" className="animated-underline text-ink-2">
                      wallet
                    </Link>
                  </p>
                </div>
              </div>
            </main>

            {inspector && graphPlacement === "Split right" && (
              <div className="hidden min-h-0 w-[460px] shrink-0 lg:block xl:w-[580px] 2xl:w-[720px]">
                {panel(false)}
              </div>
            )}
          </div>

          {inspector && graphPlacement === "Split bottom" && (
            <div className="hidden h-[48vh] shrink-0 border-t border-line lg:block">
              {panel(true)}
            </div>
          )}
        </div>
      </div>

      {inspector && graphPlacement === "Full focus" && (
        <div className="fixed inset-0 z-40 bg-paper p-3">
          <div className="mx-auto h-full max-w-5xl overflow-hidden rounded-xl border border-line shadow-2xl">
            {panel(true)}
          </div>
        </div>
      )}

      {inspector && (graphPlacement === "Right drawer" || graphPlacement === "Split right") && (
        <div
          className={`fixed inset-0 z-40 flex ${graphPlacement === "Split right" ? "lg:hidden" : ""}`}
        >
          <button
            type="button"
            aria-label="Close inspector"
            onClick={() => setInspector(null)}
            className="flex-1 bg-ink/20"
          />
          <div className="h-full w-[min(460px,94vw)] shadow-xl">{panel(false)}</div>
        </div>
      )}

      {inspector && graphPlacement === "Split bottom" && (
        <div className="fixed inset-0 z-40 flex flex-col lg:hidden">
          <button
            type="button"
            aria-label="Close inspector"
            onClick={() => setInspector(null)}
            className="flex-1 bg-ink/20"
          />
          <div className="h-[70vh] shadow-xl">{panel(true)}</div>
        </div>
      )}


      {awaiting && proposalEvent?.proposal && proposalVariant === "Takeover" && (
        <ProposalGate
          proposal={proposalEvent.proposal}
          onApprove={run.approve}
          onDecline={run.decline}
        />
      )}
    </div>
  );
}
