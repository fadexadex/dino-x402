import { createFileRoute, Link } from "@tanstack/react-router";
import { DinoMark } from "@/components/agent/DinoMark";
import { ACCOUNT } from "@/lib/agent-script";

export const Route = createFileRoute("/connect")({
  head: () => ({
    meta: [
      { title: "Connect a wallet — Dino Agent" },
      {
        name: "description",
        content:
          "Connect a Hedera account so Dino Agent can read your real portfolio and, within the limits you set, act on it.",
      },
      { property: "og:title", content: "Connect a wallet — Dino Agent" },
      {
        property: "og:description",
        content: "One connect moment, then the agent takes over. Read-only until you say otherwise.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ConnectPage,
});

function ConnectPage() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-paper px-4">
      <div className="w-full max-w-sm">
        <span className="flex items-center gap-2 text-ink">
          <DinoMark size={26} />
          <span className="text-[15px] font-semibold tracking-[-0.01em]">Dino Agent</span>
        </span>
        <h1 className="mt-6 text-[22px] leading-tight font-semibold tracking-[-0.02em] text-ink">
          Connect an account for the agent to watch
        </h1>
        <p className="mt-2 text-[13px] leading-relaxed text-ink-2">
          Until an account is connected there is no real portfolio to observe. The agent starts
          read-only — it cannot spend or trade until you raise the autonomy mode yourself.
        </p>

        <div className="mt-6 grid gap-2">
          {["HashPack", "Blade", "Kabila"].map((w) => (
            <Link
              key={w}
              to="/"
              onClick={() => {
                try {
                  window.localStorage.setItem("dino-agent.connected", "1");
                } catch {
                  /* ignore */
                }
              }}
              className="flex items-center justify-between rounded-lg border border-line bg-card px-3.5 py-3 transition-colors hover:bg-hover"
            >
              <span className="text-[13px] font-medium text-ink">{w}</span>
              <span className="font-mono text-[11px] text-ink-3">testnet</span>
            </Link>
          ))}
        </div>


        <p className="mt-4 font-mono text-[11px] text-ink-3">
          last used · {ACCOUNT}
        </p>
        <Link to="/" className="animated-underline mt-4 inline-block text-[12.5px] text-ink-2">
          Continue with the demo account →
        </Link>
      </div>
    </main>
  );
}
