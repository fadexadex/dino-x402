import { useEffect, useState } from "react";
import { VARIANT_REGISTRY, useVariants, type VariantKey } from "@/lib/variants";

export function VariantSwitcher({ onReplay }: { onReplay: () => void }) {
  const { variants, set, reset, density, setDensity } = useVariants();
  const [open, setOpen] = useState(false);
  const [dark, setDark] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === "v" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((o) => !o);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="fixed right-4 bottom-4 z-50 flex items-center gap-2 rounded-full border border-line bg-card px-3 py-2 text-[12px] font-medium text-ink shadow-lg transition-colors hover:bg-hover"
      >
        <span className="grid grid-cols-2 gap-[2px]">
          {[0, 1, 2, 3].map((i) => (
            <span key={i} className="size-[3px] rounded-[1px] bg-ink" />
          ))}
        </span>
        Variants
        <kbd className="font-mono text-[10px] text-ink-3">⌘V</kbd>
      </button>

      {open && (
        <div
          className="fixed right-4 bottom-16 z-50 max-h-[70vh] w-80 overflow-auto rounded-xl border border-line bg-card p-3 shadow-2xl"
          style={{ animation: "fade-up 200ms cubic-bezier(0.23,1,0.32,1) both" }}
        >
          <div className="flex items-baseline justify-between">
            <p className="text-[12.5px] font-medium text-ink">Design variants</p>
            <button
              type="button"
              onClick={reset}
              className="text-[11px] text-ink-3 hover:text-ink"
            >
              Reset
            </button>
          </div>
          <p className="mt-0.5 text-[11px] leading-relaxed text-ink-3">
            Every version applies live on the real screen. Your picks are remembered.
          </p>

          <div className="mt-3 grid gap-3">
            {(Object.keys(VARIANT_REGISTRY) as VariantKey[]).map((key) => {
              const entry = VARIANT_REGISTRY[key];
              return (
                <div key={key}>
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="text-[12px] font-medium text-ink">{entry.label}</span>
                    <span className="truncate text-[10.5px] text-ink-3">{entry.hint}</span>
                  </div>
                  <div className="mt-1 flex flex-wrap gap-1">
                    {entry.options.map((opt) => (
                      <button
                        key={opt}
                        type="button"
                        onClick={() => set(key, opt)}
                        className={`rounded-control border px-2 py-1 text-[11.5px] transition-colors ${
                          variants[key] === opt
                            ? "border-signal bg-signal-soft text-signal"
                            : "border-line text-ink-2 hover:bg-hover"
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-3 grid gap-2 border-t border-line pt-3">
            <div className="flex items-center justify-between">
              <span className="text-[12px] text-ink-2">Density</span>
              <div className="flex gap-1">
                {(["comfortable", "compact"] as const).map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setDensity(d)}
                    className={`rounded-control border px-2 py-1 text-[11.5px] ${
                      density === d ? "border-signal text-signal" : "border-line text-ink-2"
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-[12px] text-ink-2">Theme</span>
              <button
                type="button"
                onClick={() => setDark((d) => !d)}
                className="rounded-control border border-line px-2 py-1 text-[11.5px] text-ink-2"
              >
                {dark ? "Dark" : "Light"}
              </button>
            </div>
            <button
              type="button"
              onClick={onReplay}
              className="rounded-control bg-ink px-2 py-1.5 text-[12px] font-medium text-background"
            >
              Replay the agent run
            </button>
          </div>
        </div>
      )}
    </>
  );
}
