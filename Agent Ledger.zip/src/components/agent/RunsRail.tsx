import { HOLDINGS, OBJECTIVE } from "@/lib/agent-script";
import { num, usd } from "@/lib/format";

const RUNS = [
  { id: "0142", label: "Rotate excess HBAR", status: "Awaiting you", tone: "orange" },
  { id: "0141", label: "Concentration check", status: "No action", tone: "muted" },
  { id: "0140", label: "Rotate excess HBAR", status: "Settled", tone: "green" },
  { id: "0139", label: "Daily snapshot", status: "No action", tone: "muted" },
  { id: "0138", label: "Momentum window", status: "Expired", tone: "muted" },
];

export function RunsRail({ pendingCount }: { pendingCount: number }) {
  const total = HOLDINGS.reduce((s, h) => s + h.usd, 0);
  return (
    <div className="flex flex-col gap-3">
      <div className="rounded-lg border border-line bg-card p-3">
        <p className="text-[10.5px] font-medium tracking-[0.09em] text-ink-3 uppercase">
          Objective
        </p>
        <p className="mt-1.5 text-[12px] leading-relaxed text-ink-2">{OBJECTIVE}</p>
        <div className="mt-2.5 border-t border-line pt-2.5">
          <div className="flex items-baseline justify-between">
            <span className="text-[11.5px] text-ink-3">Portfolio</span>
            <span className="font-mono text-[13px] font-medium text-ink tabular-nums">
              {usd(total)}
            </span>
          </div>
          <ul className="mt-1.5 grid gap-1">
            {HOLDINGS.map((h) => (
              <li key={h.asset} className="flex items-baseline justify-between text-[11.5px]">
                <span className="text-ink-2">{h.asset}</span>
                <span className="font-mono text-ink-3 tabular-nums">
                  {num(h.amount, 2)} · {usd(h.usd)}
                </span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="max-h-[46vh] shrink-0 overflow-y-auto rounded-lg border border-line bg-card p-3">
        <div className="flex items-center justify-between">
          <p className="text-[10.5px] font-medium tracking-[0.09em] text-ink-3 uppercase">Runs</p>
          {pendingCount > 0 && (
            <span className="rounded-full bg-orange-soft px-1.5 py-0.5 font-mono text-[10.5px] font-medium text-orange">
              {pendingCount} waiting
            </span>
          )}
        </div>
        <ul className="mt-2 grid gap-0.5">
          {RUNS.map((r, i) => (
            <li key={r.id}>
              <button
                type="button"
                className={`w-full rounded-control px-2 py-1.5 text-left transition-colors hover:bg-hover ${i === 0 ? "bg-hover-2" : ""}`}
              >
                <div className="flex items-baseline justify-between gap-2">
                  <span className="truncate text-[12px] font-medium text-ink">{r.label}</span>
                  <span className="font-mono text-[10.5px] text-ink-3">{r.id}</span>
                </div>
                <span
                  className={`text-[11px] ${
                    r.tone === "orange"
                      ? "text-orange"
                      : r.tone === "green"
                        ? "text-green"
                        : "text-ink-3"
                  }`}
                >
                  {r.status}
                </span>
              </button>
            </li>
          ))}
        </ul>
        <p className="mt-2 border-t border-line pt-2 text-[11px] text-ink-3">
          137 earlier runs summarised
        </p>
      </div>
    </div>
  );
}
