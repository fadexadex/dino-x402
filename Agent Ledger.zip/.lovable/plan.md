# Dino Agent — agent-first interface design

A design-only build: animated mock data, no backend. The product surface is a **conversation with an autonomous agent**, not a dashboard. Charts, ledgers and history are things the agent *opens for you*, or that you pull up on demand — never the default frame.

## Visual direction

Cloud White + Signal, deliberately un-vibecoded:
- Surfaces `#fafbfc` / `#e8ecf1`, ink near-black, secondary `#94a3b8`, single saturated signal `#3b82f6` reserved for money and on-chain events only.
- Two semantic accents beyond the signal: settled/verified green, held-for-approval amber. Nothing else gets color.
- Typography: geometric sans for UI, tabular mono for every number, hash, HBAR amount and elapsed timer. Sharp-ish radii (6px), hairline borders, no gradient cards, no glassmorphism, no drop-shadow stacks.
- Dino identity: a small monoline dinosaur mark, not a Sparkles icon.

## Layout

```text
┌────────────┬──────────────────────────────┬──────────────┐
│ runs rail  │      AGENT STREAM            │  inspector   │
│ (collapsed │  live reasoning, paid data,  │  (opens on   │
│  by default│  proposals, settled trades   │   demand:    │
│ )          │  ─────────────────────────── │   graph /    │
│            │      prompt input            │   trace /    │
└────────────┴──────────────────────────────┴──────────────┘
```
The inspector is closed by default. The agent can request it ("opened the composition graph"), or the user clicks any event to pull it open. Everything the agent does is legible without it.

## Components (each shipped in 2–3 switchable variants)

Reused from the uploaded sample kit, restyled to the palette:
- `ThinkingState` / `ThinkingReasoning` / `ThinkingStateSimple` → the agent's Observe→Judge→Acquire→Reason trace
- `LoadingState` → in-flight on-chain state (submitted, not yet confirmed)
- `ApprovalCard` → Mode 3 proposal gate
- `TodoList` → scheduled check-in run steps
- `PromptInput` → composer with slash commands (`/watch`, `/mode`, `/halt`)
- `DataTable` → spend ledger

New, purpose-built:
1. **Agent event card** — one lifecycle step. Variants: *Trace line* (dense timeline), *Card stack* (bordered blocks), *Terminal* (mono log).
2. **Paid-data receipt** — the x402 micropayment moment inline in the stream. Variants: *Inline chip*, *Receipt strip with HashScan link*, *Cost meter*.
3. **Proposal / approval gate** — exact trade, expected rate, slippage, resulting position, live expiry countdown, explicit "this becomes irreversible" line. Variants: *Inline in stream*, *Sticky bottom bar*, *Focused takeover*.
4. **Autonomy dial** — Modes 1–4 with the exact numeric limits always visible. Variants: *Segmented stops*, *Vertical dial*, *Limits card*.
5. **Watch status** — last check-in / next check-in / pause. Variants: *Header pill*, *Rail block*.
6. **Live graph** — portfolio composition + market context overlay, streaming ticks, trade markers you can click through to a full trace, honest gaps where no data was purchased and explicit live/fallback provenance dots. Variants: *Overlay dual-axis*, *Split stacked*, *Sparkline strip*.
7. **Spend ledger** — data spend vs. trade volume, per-run and cumulative. Variants: *Split bar*, *Table*.
8. **Kill switch** — global halt with confirm, stops the scheduler too. Variants: *Header icon*, *Rail footer*.
9. **Connect wallet** — single onboarding moment, then invisible.

## Variant switcher

A floating control (bottom-right, keyboard-toggle, remembered in localStorage) listing every component above with its variants. Switching applies live on the real screens — no separate gallery page. Also exposes theme density and a "replay the agent run" button so animated states can be re-watched.

## Animated mock behavior

A scripted run plays on load: check-in fires → observes portfolio → judges data worth buying → pays for a quote (receipt appears) → reasons → proposes a trade → gate holds it for approval → approve → submitted (in-flight loader) → verified with HashScan link → graph steps. Prices tick continuously. A second run ends in "checked in, nothing warranted" so the no-action outcome is visible too.

## Technical notes

- TanStack Start routes: `/` (agent), `/connect`. Inspector state in URL search params so a graph/trace view is linkable.
- Sample components ported into `src/components/agent/`; their CSS Modules add `@reference "../../styles.css"` where they use `@apply`, otherwise kept as-is with tokens rewired to the design system in `src/styles.css`.
- Variant selection lives in a small React context; each component reads its variant key. No backend, no Cloud, no wallet SDK.
- Per-route `head()` metadata with Dino Agent title/description.

## Open questions I'm resolving by decision, not asking

- Pending proposal is insistent: sticky bar + rail badge + countdown, not just a graph marker.
- Autonomy mode is per-objective, rolled up to a portfolio-level view.
- History summarizes after ~50 events into collapsed run groups.
- Market graph defaults to blended portfolio view, switchable per asset.
